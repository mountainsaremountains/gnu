;; Generated package description from rt-liberation.el  -*- no-byte-compile: t -*-
(define-package "rt-liberation" "7" "Emacs interface to RT" 'nil :commit "3b98d22c76de94fae16434517b99525fabc58f31" :authors '(("Yoni Rabkin" . "yrk@gnu.org")) :maintainer '("Yoni Rabkin" . "yrk@gnu.org") :keywords '("rt" "tickets") :url "http://www.nongnu.org/rtliber/")
