;; Generated package description from dismal.el  -*- no-byte-compile: t -*-
(define-package "dismal" "1.5.2" "Dis Mode Ain't Lotus: Spreadsheet program Emacs" '((cl-lib "0")) :commit "670c0001026ff437d14545aeed3ef5745f0a53d2" :url "https://elpa.gnu.org/packages/dismal.html" :authors '((nil . "fox@cs.nyu.edu") (nil . "ritter@cs.cmu.edu")) :maintainer '("UnMaintainer" . "emacs-devel@gnu.org"))
