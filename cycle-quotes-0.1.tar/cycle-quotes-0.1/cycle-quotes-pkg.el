;; Generated package description from cycle-quotes.el  -*- no-byte-compile: t -*-
(define-package "cycle-quotes" "0.1" "Cycle between quote styles" 'nil :commit "836b19b39651419876e65cdb1a91e3eef83cc4e7" :url "https://elpa.gnu.org/packages/cycle-quotes.html" :authors '(("Simen Heggestøyl" . "simenheg@gmail.com")) :maintainer '("Simen Heggestøyl" . "simenheg@gmail.com") :keywords '("convenience"))
