;; Generated package description from gnus-mock.el  -*- no-byte-compile: t -*-
(define-package "gnus-mock" "0.5" "Mock Gnus installation for testing" 'nil :commit "0ec119ff8ddca61fc0f3e05ac4e895d57cb2ca21" :url "https://elpa.gnu.org/packages/gnus-mock.html" :authors '(("Eric Abrahamsen" . "eric@ericabrahamsen.net")) :maintainer '("Eric Abrahamsen" . "eric@ericabrahamsen.net"))
