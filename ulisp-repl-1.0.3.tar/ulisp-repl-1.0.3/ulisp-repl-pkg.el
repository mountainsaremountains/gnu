;; Generated package description from ulisp-repl.el  -*- no-byte-compile: t -*-
(define-package "ulisp-repl" "1.0.3" "uLisp REPL" '((emacs "26.1")) :commit "63e38a9080b2d15146680022e20700db6eb20657" :url "https://elpa.gnu.org/packages/ulisp-repl.html" :authors '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")) :maintainer '("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
