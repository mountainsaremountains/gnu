;; Generated package description from srht.el  -*- no-byte-compile: t -*-
(define-package "srht" "0.4" "Sourcehut" '((emacs "27.1") (plz "0.7") (transient "0.4.3")) :commit "053c79fb41278f11e98c61785e8cc500ed4c853b" :authors '(("Aleksandr Vityazev" . "avityazev@posteo.org")) :maintainer '("Aleksandr Vityazev" . "avityazev@posteo.org") :keywords '("comm" "vc") :url "https://sr.ht/~akagi/srht.el/")
