;; Generated package description from uni-confusables.el  -*- no-byte-compile: t -*-
(define-package "uni-confusables" "0.3" "Unicode confusables table" 'nil :commit "393e1adeec5b0eb51f9606983655cfe2272c6e54" :url "https://elpa.gnu.org/packages/uni-confusables.html" :maintainer '("Teodor Zlatanov" . "tzz@lifelogs.com"))
