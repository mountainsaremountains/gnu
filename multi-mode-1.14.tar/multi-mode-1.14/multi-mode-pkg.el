;; Generated package description from multi-mode.el  -*- no-byte-compile: t -*-
(define-package "multi-mode" "1.14" "support for multiple major modes" 'nil :commit "03dae71ad44bd5d10495011f124a1cd6f43f795d" :authors '(("Dave Love" . "fx@gnu.org")) :maintainer '("Dave Love" . "fx@gnu.org") :keywords '("languages" "extensions" "files") :url "http://www.loveshack.ukfsn.org/emacs")
