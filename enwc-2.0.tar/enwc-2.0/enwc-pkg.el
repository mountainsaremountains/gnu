;; Generated package description from enwc.el  -*- no-byte-compile: t -*-
(define-package "enwc" "2.0" "The Emacs Network Client" '((emacs "25.1")) :commit "9893d7f17a2ee7f83587c305c256bd1300995125" :authors '(("Ian Dunn" . "dunni@gnu.org")) :maintainer '("Ian Dunn" . "dunni@gnu.org") :keywords '("external" "network" "wicd" "manager" "nm") :url "https://savannah.nongnu.org/p/enwc")
