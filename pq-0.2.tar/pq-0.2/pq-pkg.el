;; Generated package description from pq.el  -*- no-byte-compile: t -*-
(define-package "pq" "0.2" "libpq binding" '((emacs "25")) :commit "4dad5fcdbbb362a0dc2dfa7b5a38dd5be1551c68" :authors '(("Tom Gillespie" . "tgbugs@gmail.com")) :maintainer '("Tom Gillespie" . "tgbugs@gmail.com") :url "https://github.com/anse1/emacs-libpq")
