;; Generated package description from pabbrev.el  -*- no-byte-compile: t -*-
(define-package "pabbrev" "4.3.0" "Predictive abbreviation expansion" '((emacs "25.1")) :commit "0c281401b47bd67d2726326c1a415c2bd219395f" :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")) :maintainer '("Arthur Miller" . "arthur.miller@live.com") :url "https://github.com/phillord/pabbrev")
