;; Generated package description from poke-mode.el  -*- no-byte-compile: t -*-
(define-package "poke-mode" "3.1" "Major mode for editing Poke programs" 'nil :commit "340bb45867cce7f86d09a00b809c2c2078302a9e" :url "https://elpa.gnu.org/packages/poke-mode.html" :authors '(("Aurelien Aptel" . "aaptel@suse.com")) :maintainer '("Jose E. Marchesi" . "jemarch@gnu.org"))
