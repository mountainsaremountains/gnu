;; Generated package description from mines.el  -*- no-byte-compile: t -*-
(define-package "mines" "1.6" "Minesweeper game" '((emacs "24.4") (cl-lib "0.5")) :commit "868e9b9650be1bcc1a5e6ff5a66806eccd1fe26e" :authors '(("Tino Calancha" . "tino.calancha@gmail.com")) :maintainer '("Tino Calancha" . "tino.calancha@gmail.com") :keywords '("games") :url "https://github.com/calancha/Minesweeper")
