;; Generated package description from osc.el  -*- no-byte-compile: t -*-
(define-package "osc" "0.4" "Open Sound Control protocol library" 'nil :commit "6b6dbb4176f45f9ff3a783c816c4556ca2931a22" :url "https://elpa.gnu.org/packages/osc.html" :authors '(("Mario Lang" . "mlang@blind.guru")) :maintainer '("Mario Lang" . "mlang@blind.guru") :keywords '("comm" "processes" "multimedia"))
