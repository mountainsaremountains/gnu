1.5.1 2019-07-15
================

* Remove "lexical-let"
* recursive-autoloads: Remove autoloads from packages that no longer are
  included, e.g. ipdb, jdb, nodejs
* Require 25.1 or greater pervasively; :version 24.3 -> 25.1 wherever
  that appears
* perldb.el: fix small cut-and-paste holdover
* NEWS -> NEWS.md
* Miscellaneous bugs fixed


1.5.0 2019-04-28
================

Emacs 25 or greater is now required.

ipdb, jdb, and nodejs (older node debug) removed from core. Get them as separate packages.

1.4.8 2019-04-25
================

Mostly lint-like fixes and a couple bug fixes to boot.


Emacs 25 or greater is now required.

ipdb, jdb, and nodejs (older node debug) removed from core. Get them as separate packages.

1.4.6 2019-04-04
================

Numerous changes and bug fixes. The main new feature though is adding a breakpoint buffer that is akin to the backtrace buffer.

1.4.5 2018-03-22
================

Stable version before a minor upheaval
