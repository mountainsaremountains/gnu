;; Generated package description from ob-haxe.el  -*- no-byte-compile: t -*-
(define-package "ob-haxe" "1.0" "org-babel functions for haxe evaluation" 'nil :commit "d52fa3bc87310a560bed8e6362e412c4b3d73294" :authors '(("Ian Martins" . "ianxm@jhu.edu")) :maintainer '("Ian Martins" . "ianxm@jhu.edu") :keywords '("literate programming" "reproducible research") :url "https://orgmode.org")
