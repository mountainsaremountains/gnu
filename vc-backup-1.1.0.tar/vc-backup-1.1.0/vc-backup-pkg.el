;; Generated package description from vc-backup.el  -*- no-byte-compile: t -*-
(define-package "vc-backup" "1.1.0" "VC backend for versioned backups" 'nil :commit "397af1e12b2e73a00370cc3ac054ffe2402b3352" :authors '(("Philip Kaludercic" . "philipk@posteo.net")) :maintainer '("Philip Kaludercic" . "philipk@posteo.net") :keywords '("vc") :url "https://git.sr.ht/~pkal/vc-backup")
