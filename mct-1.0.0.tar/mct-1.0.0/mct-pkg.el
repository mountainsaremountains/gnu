;; Generated package description from mct.el  -*- no-byte-compile: t -*-
(define-package "mct" "1.0.0" "Minibuffer Confines Transcended" '((emacs "29.1")) :commit "2cbf74edb4f4553d7075b34e06adcf59e96efda2" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://git.sr.ht/~protesilaos/mct")
