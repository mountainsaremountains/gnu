;; Generated package description from realgud-ipdb.el  -*- no-byte-compile: t -*-
(define-package "realgud-ipdb" "1.0.0" "realgud front-end to ipdb" '((realgud "1.4.5") (emacs "24")) :commit "ba41636ac4102bdc9d28a5ae7177b3792be55933" :url "http://github.com/rocky/realgud-ipdb")
