;; Generated package description from ioccur.el  -*- no-byte-compile: t -*-
(define-package "ioccur" "2.6" "Incremental occur" '((emacs "24") (cl-lib "0.5")) :commit "33bf6f73e314ade8da27dd793c69c21312c97f10" :authors '(("Thierry Volpiatto" . "thievol@posteo.net")) :maintainer '("Thierry Volpiatto" . "thievol@posteo.net") :url "https://github.com/thierryvolpiatto/ioccur")
