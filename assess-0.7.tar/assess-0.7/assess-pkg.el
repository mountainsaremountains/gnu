;; Generated package description from assess.el  -*- no-byte-compile: t -*-
(define-package "assess" "0.7" "Test support functions" '((emacs "24.4") (m-buffer "0.15")) :commit "cadeb24a5d8261fad4bdfdc09e7d571cc395a6ca" :url "https://elpa.gnu.org/packages/assess.html" :authors '(("Phillip Lord" . "phillip.lord@russet.org.uk")) :maintainer '("Phillip Lord" . "phillip.lord@russet.org.uk"))
