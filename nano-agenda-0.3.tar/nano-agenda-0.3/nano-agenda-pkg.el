;; Generated package description from nano-agenda.el  -*- no-byte-compile: t -*-
(define-package "nano-agenda" "0.3" "N Λ N O agenda" '((emacs "27.1")) :commit "6c38e95b8e846aceb88398c682fd283052924556" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience" "org-mode" "org-agenda") :url "https://github.com/rougier/nano-agenda")
