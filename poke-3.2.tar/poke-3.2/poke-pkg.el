;; Generated package description from poke.el  -*- no-byte-compile: t -*-
(define-package "poke" "3.2" "Emacs meets GNU poke!" '((emacs "25")) :commit "77bdcce97e06bbd6771f35acbb3f399457bebb71" :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Jose E. Marchesi" . "jemarch@gnu.org") :url "https://www.jemarch.net/poke")
