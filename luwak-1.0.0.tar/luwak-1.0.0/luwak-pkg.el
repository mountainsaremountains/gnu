;; Generated package description from luwak.el  -*- no-byte-compile: t -*-
(define-package "luwak" "1.0.0" "Web browser based on lynx -dump." '((emacs "28")) :commit "37a36288c8d4cdba461812dbdf5da434ca156fee" :authors '(("Yuchen Pei" . "id@ypei.org")) :maintainer '("Yuchen Pei" . "id@ypei.org") :keywords '("web-browser" "lynx" "html" "tor") :url "https://g.ypei.me/luwak.git")
